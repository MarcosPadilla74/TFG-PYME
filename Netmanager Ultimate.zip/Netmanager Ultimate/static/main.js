const modalConfirmacion = document.getElementById("ventana-confirmacion");

function abrirModal() { 
    modalConfirmacion.style.display = "flex";
    console.log("Sistema: El usuario ha solicitado una gestión de servicio.");
}

function cerrarModal() {
     modalConfirmacion.style.display = "none";
}

function confirmarAccion() {
    alert("¡Orden enviada! El servicio se está procesando en el servidor.");
    cerrarModal();
}

window.onclick = function(event) {
    if (event.target == modalConfirmacion) {
        cerrarModal();
    }
}

// Esta función se activa cuando pulsas el botón del HTML
function enviarTicket() {
    // 1. Cogemos el texto que hay dentro de cada caja del HTML
    var elUsuario = document.getElementById("ticket-usuario").value;
    var elTipo = document.getElementById("ticket-tipo").value;
    var laDescripcion = document.getElementById("ticket-descripcion").value;

    // 2. Si alguna caja está vacía, regañamos al usuario y no hacemos nada más
    if (elUsuario == "" || laDescripcion == "") {
        alert("Tienes que rellenar todos los campos.");
        return; 
    }

    // 3. Juntamos los datos en una mochila para el cartero (FormData es lo más fácil)
    var mochila = new FormData();
    mochila.append("usuario_html", elUsuario);
    mochila.append("tipo_html", elTipo);
    mochila.append("descripcion_html", laDescripcion);

    // 4. Mandamos al cartero corriendo hacia la ruta de Python llamada '/guardar-ticket'
    fetch('/guardar-ticket', {
        method: 'POST',
        body: mochila
    })
    .then(function(respuesta) {
        // Cuando llega el cartero de vuelta, comprobamos que todo esté OK
        if (respuesta.ok) {
            alert("El ticket se ha guardado en el servidor.");
            // Vaciamos el formulario para que se quede limpito
            document.getElementById("form-ticket").reset();
        } else {
            alert("El servidor ha dado un error.");
        }
    });
}