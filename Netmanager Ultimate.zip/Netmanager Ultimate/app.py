import subprocess
import os
import re
from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)

@app.route('/')
def inicio():
    try:
        status_dhcp = subprocess.run(['systemctl', 'is-active', 'isc-dhcp-server'], capture_output=True, text=True).stdout.strip()
        status_ftp = subprocess.run(['systemctl', 'is-active', 'vsftpd'], capture_output=True, text=True).stdout.strip()
        status_ssh = subprocess.run(['systemctl', 'is-active', 'ssh'], capture_output=True, text=True).stdout.strip()
    except:
        status_dhcp = status_ftp = status_ssh = "inactive"
    return render_template('index.html', dhcp_vivo=status_dhcp, ftp_vivo=status_ftp, ssh_vivo=status_ssh)

@app.route('/servicios')
def ver_servicios():
    try:
        s_ssh = subprocess.run(['systemctl', 'is-active', 'ssh'], capture_output=True, text=True).stdout.strip()
        s_dhcp = subprocess.run(['systemctl', 'is-active', 'isc-dhcp-server'], capture_output=True, text=True).stdout.strip()
        s_ftp = subprocess.run(['systemctl', 'is-active', 'vsftpd'], capture_output=True, text=True).stdout.strip()
    except:
        s_ssh = s_dhcp = s_ftp = "inactive"
    return render_template('servicios.html', s_ssh=s_ssh, s_dhcp=s_dhcp, s_ftp=s_ftp)

@app.route('/reiniciar/<servicio>')
def reiniciar_servicio(servicio):
    nombres = {"ssh": "ssh", "dhcp": "isc-dhcp-server", "ftp": "vsftpd"}
    try:
        subprocess.run(['sudo', 'systemctl', 'restart', nombres.get(servicio)], check=True)
        return redirect(url_for('inicio'))
    except Exception as e: return str(e)

@app.route('/configurar/dhcp', methods=['GET', 'POST'])
def configurar_dhcp():
    if request.method == 'GET':
        config_actual = {"subred": "-", "mascara": "-", "inicio": "-", "fin": "-", "router": "-"}
        try:
            if os.path.exists('/etc/dhcp/dhcpd.conf'):
                with open('/etc/dhcp/dhcpd.conf', 'r') as f:
                    content = f.read()
                    sub = re.search(r"subnet ([\d.]+) netmask ([\d.]+)", content)
                    if sub:
                        config_actual["subred"] = sub.group(1)
                        config_actual["mascara"] = sub.group(2)
                    
                    rng = re.search(r"range ([\d.]+) ([\d.]+)", content)
                    if rng:
                        config_actual["inicio"] = rng.group(1)
                        config_actual["fin"] = rng.group(2)
                    
                    rt = re.search(r"option routers ([\d.]+)", content)
                    if rt:
                        config_actual["router"] = rt.group(1)
        except Exception as e:
            print(f"Error leyendo config: {e}")
            
        return render_template('dhcp.html', c=config_actual)

    subred = request.form['subred']
    mascara = request.form['mascara']
    rango_inicio = request.form['rango_inicio']
    rango_fin = request.form['rango_fin']
    router = request.form['router']

    nueva_configuracion = f"""
# Generado por NetManager
default-lease-time 600;
max-lease-time 7200;
authoritative;

subnet {subred} netmask {mascara} {{
    range {rango_inicio} {rango_fin};
    option routers {router};
    option domain-name-servers 8.8.8.8, 8.8.4.4;
}}
"""
    try:
        ruta_tmp = "/tmp/dhcpd.conf.tmp"
        with open(ruta_tmp, 'w') as f: f.write(nueva_configuracion)
        subprocess.run(['sudo', 'mv', ruta_tmp, '/etc/dhcp/dhcpd.conf'], check=True)
        subprocess.run(['sudo', 'systemctl', 'restart', 'isc-dhcp-server'], check=True)
        return redirect(url_for('configurar_dhcp'))
    except Exception as e:
        return f"Error: {e}"

@app.route('/configurar/ftp')
def configurar_ftp():
    usuarios = [n for n in os.listdir('/home') if n != 'tfg']
    return render_template('ftp.html', usuarios=usuarios)

@app.route('/crear-usuario-ftp', methods=['POST'])
def crear_usuario_ftp():
    u, p = request.form['username'], request.form['password']
    try:
        subprocess.run(['sudo', 'useradd', '-m', '-s', '/usr/sbin/nologin', u], check=True)
        subprocess.run(['sudo', 'chpasswd'], input=f"{u}:{p}", text=True, check=True)
        return redirect(url_for('configurar_ftp'))
    except Exception as e: return str(e)

@app.route('/eliminar-usuario-ftp', methods=['POST'])
def eliminar_usuario_ftp():
    u = request.form['username']
    try:
        subprocess.run(['sudo', 'userdel', '-r', u], check=True)
        return redirect(url_for('configurar_ftp'))
    except Exception as e: return str(e)

@app.route('/faq')
def ver_faq():
    return render_template('faq.html')

@app.route('/tickets')
def ver_tickets():
    return render_template('tickets.html')

@app.route('/guardar-ticket', methods=['POST'])
def guardar_ticket_en_servidor():
    try:
        quien = request.form['usuario_html']
        que_pasa = request.form['tipo_html']
        detalle = request.form['descripcion_html']
        texto_final = f"USUARIO: {quien} | INCIDENCIA: {que_pasa} | DETALLE: {detalle}\n"
        with open("tickets_soporte.txt", "a", encoding="utf-8") as archivo:
            archivo.write(texto_final)
        return "Hecho"
    except Exception as e:
        return str(e), 500

@app.route('/ver-tickets')
def ver_tickets_guardados():
    try:
        with open("tickets_soporte.txt", "r", encoding="utf-8") as archivo:
            todas_las_lineas = archivo.readlines()
        filas_de_la_tabla = ""
        for una_linea in todas_las_lineas:
            if una_linea.strip() != "":
                partes = una_linea.split("|")
                nombre_limpio = partes[0].replace("USUARIO:", "").strip()
                tipo_limpio = partes[1].replace("INCIDENCIA:", "").strip()
                detalle_limpio = partes[2].replace("DETALLE:", "").strip()
                filas_de_la_tabla += f"""
                <tr>
                    <td><strong> {nombre_limpio} </strong></td>
                    <td><span class="estado active"> {tipo_limpio} </span></td>
                    <td> {detalle_limpio} </td>
                </tr>
                """
        pagina_completa = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title> NetManager - Historial </title>
            <link rel="stylesheet" href="/static/style.css">
        </head>
        <body>
            <div class="contenido-principal">
                <h1 class="titulo-seccion"> Historial de Incidencias </h1>
                <p class="subtitulo"> Listado de problemas técnicos guardados en el servidor. </p>
                <div class="seccion-ftp">
                    <h2 class="titulo-modulo"> Tickets Registrados </h2>
                    <div class="contenedor-tabla">
                        <table class="tabla-servicios">
                            <thead>
                                <tr>
                                    <th> Usuario </th>
                                    <th> Avería </th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filas_de_la_tabla}
                            </tbody>
                        </table>
                    </div>
                </div>
                <br>
                <a href="/" class="boton-guardar"> Volver </a>
            </div>
        </body>
        </html>
        """
        return pagina_completa
    except Exception as e:
        return """
        <!DOCTYPE html>
        <html>
        <head><link rel="stylesheet" href="/static/style.css"></head>
        <body>
            <div class="contenido-principal">
                <h2 class="titulo-seccion"> Aún no hay ningún ticket registrado </h2>
                <p class="subtitulo"> El bloc de notas del servidor está limpio. </p>
                <br>
                <a href="/" class="boton-guardar"> Volver </a>
            </div>
        </body>
        </html>
        """

@app.route('/estado/<servicio>')
def ver_estado(servicio):
    nombres = {"ssh": "ssh", "dhcp": "isc-dhcp-server", "ftp": "vsftpd"}
    try:
        res = subprocess.run(['systemctl', 'status', nombres.get(servicio)], capture_output=True, text=True)
        resultado_consola = res.stdout
        pagina_logs = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <link rel="stylesheet" href="/static/style.css">
            <title>NetManager - Logs {servicio.upper()}</title>
        </head>
        <body>
            <div class="contenido-principal">
                <h1 class="titulo-seccion"> Registros del Sistema (Logs) </h1>
                <p class="subtitulo"> Inspección de eventos en tiempo real para: <strong>{servicio.upper()}</strong></p>
                <div class="seccion-ftp">
                    <h2 class="titulo-modulo"> Salida del comando systemctl status </h2>
                    <pre> {resultado_consola} </pre>
                </div>
                <br>
                <a href="/" class="boton-guardar"> Volver </a>
            </div>
        </body>
        </html>
        """
        return pagina_logs
    except Exception as e: 
        return str(e)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9000, debug=True)