// GESTIÓN DE LA VENTANA MODAL (EL CARTEL DE AVISO)

// Buscamos en el HTML el elemento con ID "ventana-confirmacion" y lo guardamos en una variable
const modalConfirmacion = document.getElementById("ventana-confirmacion");

// Función que se activa al pulsar el botón "Gestionar" o "Guardar"
function abrirModal() {
    // Cambiamos el estilo de "none" (invisible) a "flex" (visible y centrado)
    modalConfirmacion.style.display = "flex";
    // Dejamos una nota en la consola del navegador para depuración técnica
    console.log("Sistema: El usuario ha solicitado una gestión de servicio.");
}

// Función que se activa al pulsar "No", "Cancelar" o el botón de cerrar
function cerrarModal() {
    // Volvemos a ocultar la ventana poniendo el estilo en "none"
    modalConfirmacion.style.display = "none";
}

// Función que simula la comunicación con el servidor Linux
function confirmarAccion() {
    // Lanzamos una alerta del sistema avisando del éxito de la operación
    alert("¡Orden enviada! El servicio se está procesando en el servidor.");
    // Cerramos la ventana automáticamente para volver al panel
    cerrarModal();
}

// DETECCIÓN DE CLIC FUERA DE LA CAJA BLANCA
// Si el usuario hace clic en cualquier parte de la ventana...
window.onclick = function(event) {
    // ...y ese clic es en el fondo oscuro (no en la cajita blanca)...
    if (event.target == modalConfirmacion) {
        // ...cerramos el aviso por comodidad del usuario
        cerrarModal();
    }
}